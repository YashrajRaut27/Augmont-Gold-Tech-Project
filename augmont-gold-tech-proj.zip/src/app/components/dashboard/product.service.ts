import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  // Point this to your Node.js backend URL
  private apiUrl = 'http://localhost:3000/api/products'; 

  constructor(private http: HttpClient) {}

  // Requirement B: Handles Pagination, Price Sorting, and Text Search
  getProducts(page: number, limit: number, sortBy: 'asc' | 'desc', search: string): Observable<any> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('limit', limit.toString())
      .set('sortBy', sortBy);

    if (search) {
      params = params.set('search', search);
    }

    return this.http.get<any>(this.apiUrl, { params });
  }

  // Requirement A.4: Chunked bulk multipart file handler
  bulkUpload(file: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);
    return this.http.post(`${this.apiUrl}/bulk-upload`, formData);
  }

  // Requirement A.5: Triggers a direct stream download link to stop 504 timeouts
  downloadReport(): void {
    window.open(`${this.apiUrl}/report`, '_blank');
  }
}