import { Component, OnInit, OnDestroy } from '@angular/core';
import { ProductService } from './product.service';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {
  products: any[] = [];
  totalItems = 0;
  currentPage = 1;
  pageSize = 10;
  sortDirection: 'asc' | 'desc' = 'asc';
  currentSearchTerm = '';
  
  private searchTerms = new Subject<string>();

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.loadProducts();

    // Debounce window waiting 300ms after the user stops typing to trigger the API
    this.searchTerms.pipe(
      debounceTime(300),
      distinctUntilChanged()
    ).subscribe(term => {
      this.currentSearchTerm = term;
      this.currentPage = 1; // Always jump back to page 1 on a fresh search filter
      this.loadProducts();
    });
  }

  loadProducts(): void {
    this.productService.getProducts(this.currentPage, this.pageSize, this.sortDirection, this.currentSearchTerm)
      .subscribe({
        next: (res: any) => {
          this.products = res.data;
          this.totalItems = res.meta.totalItems;
        },
        error: (err: any) => {
          console.error('Failed to pull server-side records:', err);
        }
      });
  }

  onSearch(event: Event): void {
    const term = (event.target as HTMLInputElement).value;
    this.searchTerms.next(term);
  }

  toggleSort(): void {
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    this.loadProducts();
  }

  changePage(direction: number): void {
    this.currentPage += direction;
    this.loadProducts();
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      
      this.productService.bulkUpload(file).subscribe({
        next: () => {
          alert('Bulk upload successfully processed in database chunks!');
          this.loadProducts();
        },
        error: (err: any) => {
          alert('Upload processing failed: ' + err.message);
        }
      });
    }
  }

  exportCsvReport(): void {
    this.productService.downloadReport();
  }

  ngOnDestroy(): void {
    this.searchTerms.unsubscribe(); // Protect memory allocation maps
  }
}